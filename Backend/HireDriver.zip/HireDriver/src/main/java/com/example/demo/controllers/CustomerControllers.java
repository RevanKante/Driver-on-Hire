package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Customer;
import com.example.demo.services.CustomerService;

@CrossOrigin
@RestController
public class CustomerControllers 
{
	@Autowired
	CustomerService cs;
	
	@PostMapping("/register")
	public Customer register(@RequestBody Customer c)
	{
		return cs.register(c);
	}
}
