package com.example.demo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="customers")
public class Customer 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int uid;
	@Column
	private String fname;
	@Column
	private String lname;
	@Column
	private String email;
	@Column
	private String mobileno;
	@Column
	private String password;
	@Column
	private String city;
	@Column
	private String state;
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(String fname, String lname, String email, String mobno, String password, String city,
			String state) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.email = email;
		this.mobileno = mobileno;
		this.password = password;
		this.city = city;
		this.state = state;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobno() {
		return mobileno;
	}

	public void setMobno(String mobno) {
		this.mobileno = mobno;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "Customer [uid=" + uid + ", fname=" + fname + ", lname=" + lname + ", email=" + email + ", mobno="
				+ mobileno + ", password=" + password + ", city=" + city + ", state=" + state + "]";
	}
	
	
}
